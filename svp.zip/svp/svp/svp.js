$(document).ready(
		function(){

//Video gallery
		$(".svp_video").fancybox({
			width: 640,
			height: 328,
			padding: 3,
			closeBtn: false, 
			helpers : {
				media: true
				}
				});
});